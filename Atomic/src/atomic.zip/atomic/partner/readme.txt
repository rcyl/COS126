/******************************************************************************
 *  Name:    
 *  NetID:   
 *  Precept: 
 *
 *  Partner Name:    
 *  Partner NetID:   
 *  Partner Precept: 
 * 
 ******************************************************************************/

Which partner is submitting the program files?

Hours to complete assignment (optional): 

/**********************************************************************
 *  Enter any comments that you have about this assignment.
 **********************************************************************/
