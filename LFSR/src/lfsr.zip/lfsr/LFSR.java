/******************************************************************************
 * Name:    
 * NetID:   
 * Precept: 
 *
 * Description:
 *
 ******************************************************************************/

public class LFSR {

    // creates an LFSR with the specified seed and tap
    public LFSR(String seed, int tap) {
        // PUT YOUR CODE HERE
    }
  
    // returns the number of bits in this LFSR
    public int length()  {
        // PUT YOUR CODE HERE
    }

    // returns the ith bit of this LFSR (as 0 or 1)
    public int bitAt(int i)  {
        // PUT YOUR CODE HERE
    }

    // returns a string representation of this LFSR
    public String toString()  {
        // PUT YOUR CODE HERE
    }
   
    // simulates one step of this LFSR and returns the new bit (as 0 or 1)
    public int step() {
        // PUT YOUR CODE HERE
    }
  
    // simulates k steps of this LFSR and returns the k bits as a k-bit integer
    public int generate(int k) {
        // PUT YOUR CODE HERE
    }

    // tests this class by directly calling all instance methods
    public static void main(String[] args) {
        // PUT YOUR TEST CODE HERE
    }

}
