/******************************************************************************
 * Name:    
 * NetID:   
 * Precept: 
 *
 ******************************************************************************/


Programming Assignment 5: Linear-Feedback Shift Register

Hours to complete assignment:


/**********************************************************************
 *  What is one advantage of making two separate classes for LFSR
 *  and PhotoMagic rather than putting everything in a single class?
 **********************************************************************/



/**********************************************************************
 *  Did you fill out the mid-semester feedback form?
 *  If not, do so now: https://goo.gl/forms/1MDZ03n8pY1lj0r92
 **********************************************************************/





/**********************************************************************
 *  Did you receive help from classmates, past COS 126 students, or
 *  anyone else? If so, please list their names.  ("A Sunday lab TA"
 *  or "Office hours on Thursday" is ok if you don't know their name.)
 **********************************************************************/

Yes or no?



/**********************************************************************
 *  Did you encounter any serious problems? If so, please describe.
 **********************************************************************/

Yes or no?





/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

